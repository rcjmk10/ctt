# Outlook 365 Out of Office Settings Manager

This Spring Boot application allows you to manage out-of-office settings for Outlook 365 users using certificate-based authentication.

## Prerequisites

- Java 11 or higher
- Gradle 7.4.2 or higher
- Azure AD application with appropriate permissions
- Certificate for authentication
- Access to Microsoft Graph API

## Setup

1. Register an application in Azure AD:
   - Go to Azure Portal > Azure Active Directory > App registrations
   - Create a new registration
   - Add the following API permissions:
     - MailboxSettings.Read
     - MailboxSettings.ReadWrite
   - Create a client secret
   - Upload your certificate

2. Configure environment variables:
   ```bash
   export AZURE_CLIENT_ID=your_client_id
   export AZURE_CLIENT_SECRET=your_client_secret
   export AZURE_TENANT_ID=your_tenant_id
   export AZURE_CERTIFICATE_PATH=path_to_your_certificate.pfx
   ```

3. Build the application:
   ```bash
   ./gradlew build
   ```

4. Run the application:
   ```bash
   ./gradlew bootRun
   ```

## API Endpoints

### Get Out of Office Settings
```
GET /api/out-of-office/{userEmail}
```

### Update Out of Office Settings
```
PUT /api/out-of-office/{userEmail}?isOutOfOffice=true&message=Your out of office message
```

Parameters:
- `userEmail`: The email address of the user
- `isOutOfOffice`: Boolean indicating if out of office is enabled
- `message`: (Optional) The out of office message

## Security

- The application uses certificate-based authentication
- All sensitive information is stored in environment variables
- HTTPS is recommended for production use

## Error Handling

The application includes basic error handling for:
- Invalid credentials
- Missing permissions
- Invalid user email
- Network issues 