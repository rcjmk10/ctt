package com.example.outlook365;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Outlook365Application {
    public static void main(String[] args) {
        SpringApplication.run(Outlook365Application.class, args);
    }
} 