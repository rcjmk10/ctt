package com.example.outlook365.controller;

import com.microsoft.graph.models.MailboxSettings;
import com.example.outlook365.service.OutOfOfficeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/out-of-office")
@RequiredArgsConstructor
public class OutOfOfficeController {

    private final OutOfOfficeService outOfOfficeService;

    @GetMapping("/{userEmail}")
    public ResponseEntity<MailboxSettings> getOutOfOfficeSettings(@PathVariable String userEmail) {
        return ResponseEntity.ok(outOfOfficeService.getOutOfOfficeSettings(userEmail));
    }

    @PutMapping("/{userEmail}")
    public ResponseEntity<Void> updateOutOfOfficeSettings(
            @PathVariable String userEmail,
            @RequestParam boolean isOutOfOffice,
            @RequestParam(required = false) String message) {
        outOfOfficeService.updateOutOfOfficeSettings(userEmail, isOutOfOffice, message);
        return ResponseEntity.ok().build();
    }
} 