package com.example.outlook365.service;

import com.microsoft.graph.models.MailboxSettings;
import com.microsoft.graph.models.User;
import com.microsoft.graph.requests.GraphServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OutOfOfficeService {

    private final GraphServiceClient<User> graphServiceClient;

    public MailboxSettings getOutOfOfficeSettings(String userEmail) {
        User user = graphServiceClient.users(userEmail)
                .buildRequest()
                .select("mailboxSettings")
                .get();
        return user.mailboxSettings;
    }

    public void updateOutOfOfficeSettings(String userEmail, boolean isOutOfOffice, String message) {
        MailboxSettings mailboxSettings = new MailboxSettings();
        mailboxSettings.automaticRepliesSetting = new com.microsoft.graph.models.AutomaticRepliesSetting();
        mailboxSettings.automaticRepliesSetting.status = isOutOfOffice ? 
                com.microsoft.graph.models.AutomaticRepliesStatus.ALWAYS_ENABLED : 
                com.microsoft.graph.models.AutomaticRepliesStatus.DISABLED;
        
        if (isOutOfOffice && message != null) {
            mailboxSettings.automaticRepliesSetting.internalReplyMessage = message;
            mailboxSettings.automaticRepliesSetting.externalReplyMessage = message;
        }

        graphServiceClient.users(userEmail)
                .buildRequest()
                .patch(new User() {{
                    mailboxSettings = mailboxSettings;
                }});
    }
} 