package com.bns.outlook;

 


import com.azure.identity.ClientCertificateCredential;
import com.azure.identity.ClientCertificateCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.models.*;
import com.microsoft.graph.requests.GraphServiceClient;

import javax.annotation.Nonnull;
import java.nio.file.Paths;
import java.util.Collections;

public class OutlookGraphApp {

    private static final String CLIENT_ID = "a6022c02-b80b-45ea-aa0e-cc98ee8ca98c";
    private static final String TENANT_ID = "85de82f0-e31f-467a-847c-e871c0dfc9a2";
    private static final String CERTIFICATE_PATH = "certificate.pfx";
    private static final String CERTIFICATE_PASSWORD = "changeit";
    private static GraphServiceClient<Request> graphClient;

    public static void main(String[] args) {

        try {
            // Load client certificate credential
            ClientCertificateCredential credential = new ClientCertificateCredentialBuilder()
                    .clientId(CLIENT_ID)
                    .tenantId(TENANT_ID)
                    .pfxCertificate(Paths.get(CERTIFICATE_PATH), CERTIFICATE_PASSWORD)
                    .build();

            // Set up authentication for Microsoft Graph
            TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(
                    Collections.singletonList("https://graph.microsoft.com/.default"), credential);

            graphClient = GraphServiceClient
                    .builder()
                    .authenticationProvider(authProvider)
                    .buildClient();

            // ✅ Get Access Token (for debugging)
            String token = credential.getToken("https://graph.microsoft.com/.default").block();
            System.out.println("Access Token: " + token);

            // ✅ Get all users
            listUsers();

            // ✅ Find user by email
            String userEmail = "RichardLi@HandrockSoft.onmicrosoft.com";
            String userId = getUserIdByEmail(userEmail);
            if (userId != null) {
                System.out.println("User ID: " + userId);

                // ✅ Set Out-of-Office Message
                setOutOfOffice(userId);
            } else {
                System.out.println("User not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ List all users
    private static void listUsers() {
        try {
            UserCollectionPage users = graphClient.users()
                    .buildRequest()
                    .get();

            for (User user : users.getCurrentPage()) {
                System.out.printf("User: %s - %s - %s%n",
                        user.displayName, user.mail, user.userPrincipalName);
            }
        } catch (Exception e) {
            System.out.println("Failed to fetch user list: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ✅ Find user by email
    private static String getUserIdByEmail(String email) {
        try {
            UserCollectionPage users = graphClient
                    .users()
                    .buildRequest()
                    .filter("mail eq '" + email + "'")
                    .get();

            if (!users.getCurrentPage().isEmpty()) {
                User user = users.getCurrentPage().get(0);
                return user.id;
            }
        } catch (Exception e) {
            System.out.println("Failed to fetch user ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // ✅ Set Out-of-Office Reply
    private static void setOutOfOffice(String userId) {
        try {
            // Create out-of-office setting
            AutomaticRepliesSetting autoReply = new AutomaticRepliesSetting();
            autoReply.status = AutomaticRepliesStatus.SCHEDULED;

            // Start date
            DateTimeTimeZone startDate = new DateTimeTimeZone();
            startDate.dateTime = "2025-03-25T09:00:00";
            startDate.timeZone = "UTC";

            // End date
            DateTimeTimeZone endDate = new DateTimeTimeZone();
            endDate.dateTime = "2025-03-30T18:00:00";
            endDate.timeZone = "UTC";

            autoReply.scheduledStartDateTime = startDate;
            autoReply.scheduledEndDateTime = endDate;

            autoReply.internalReplyMessage = "I am currently out of the office.";
            autoReply.externalReplyMessage = "I'm out of the office. Please contact support@example.com.";
            autoReply.externalAudience = ExternalAudienceScope.ALL;

            // Apply the setting
            graphClient
                    .users(userId)
                    .mailboxSettings()
                    .buildRequest()
                    .patch(new MailboxSettings() {{
                        automaticRepliesSetting = autoReply;
                    }});

            System.out.println("Out-of-office set successfully!");
        } catch (Exception e) {
            System.out.println("Failed to set out-of-office: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
