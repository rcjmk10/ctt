
# PathFinder — Ansible Automation Platform (AAP) Project

This repository deploys the PathFinder application to remote Windows servers running JBoss EAP 7, including:
- Environment configuration (ports, JDBC, JGroups, node names, logs)
- EAR build and deployment (console/ui/mgmt)
- Batch mainlines registration (S‑Step / P‑Step)
- Config synchronization (Flow files, MIR/SIR, app props)
- Health checks and rolling deployments
- Secrets from HashiCorp Vault (or AAP Vault)

> Note: No binaries are included. Provide your own installers (JBoss, drivers) in an internal artifact store.

## Layout

- `inventories/` — prod & nonprod inventories
- `group_vars/` — environment‑wide settings & integrations
- `roles/` — modular roles for PF lifecycle
- `playbooks/` — site, build, rolling deploy, config sync, rollback
- `aap/job_templates/` — example JSON for AAP job templates
- `files/sample/manifest.json` — sample artifact manifest
- `vars/vault_paths.yml` — centralized mapping of Vault secret paths

## Quick start

1) Adjust `inventories/*/hosts.yml`, `group_vars/*` and `vars/vault_paths.yml`.
2) Place JDBC drivers and installers in your artifact store (referenced by URLs/credentials).
3) Run a non‑prod deploy:
```
ansible-playbook -i inventories/nonprod/hosts.yml playbooks/site.yml   -e pf_version_tag=v1.0.0 -e pf_components="page,menu,code,web" --diff
```

## Idempotency
- EAR deployment forces only when checksum differs from the published manifest.
- Config sync is drift‑aware; use `--check` for preview.

## Vault
- The roles use the `hashi_vault` lookup to pull credentials dynamically.
- AAP users can map an org‑level Vault credential to these lookups.
