package dev.lydtech.security.simpleconfidentialclient;
 

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@Component
public class JwtToOAuth2Filter extends OncePerRequestFilter {

    private final JwtToOAuth2AuthenticationTokenConverter jwtConverter;

    public JwtToOAuth2Filter(JwtToOAuth2AuthenticationTokenConverter jwtConverter) {
        this.jwtConverter = jwtConverter;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // ✅ Get the existing JWT authentication
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            // ✅ Convert to OAuth2 token
            Authentication oAuth2Auth = jwtConverter.convert(jwtAuth);
            request.getSession().setAttribute("token", jwtConverter.getToken());
            SecurityContextHolder.getContext().setAuthentication(oAuth2Auth);

            System.out.println("✅ Successfully converted JWT to OAuth2AuthenticationToken");
        }

        filterChain.doFilter(request, response);
    }
}
