package dev.lydtech.security.simpleconfidentialclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleConfidentialClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
