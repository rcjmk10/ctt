package dev.lydtech.security.simpleresourceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleResourceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleResourceServerApplication.class, args);
	}

}
