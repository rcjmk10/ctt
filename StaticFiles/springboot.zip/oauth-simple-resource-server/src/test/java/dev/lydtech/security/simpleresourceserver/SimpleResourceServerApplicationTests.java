package dev.lydtech.security.simpleresourceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
