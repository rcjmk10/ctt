package com.bns.branchtools.oauth.oauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
