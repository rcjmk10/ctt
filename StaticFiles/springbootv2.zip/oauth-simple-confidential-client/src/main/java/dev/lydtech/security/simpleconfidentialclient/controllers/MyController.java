package dev.lydtech.security.simpleconfidentialclient.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.AuthenticatedPrincipal;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.security.Principal;

@Controller
@Slf4j
@RequestMapping("/")
public class MyController {

	  private final OAuth2AuthorizedClientService clientService;

	    public MyController(OAuth2AuthorizedClientService clientService) {
	        this.clientService = clientService;
	    }
	    
    @GetMapping(path = "/")
    public String index(Model model) {
        // Need to look up principal here. By including it as a method param, Spring will redirect to login (which isn't required for this endpoint)
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof AuthenticatedPrincipal user) {
            model.addAttribute("username", user.getName());
        }
        return "public";
    }

    @GetMapping(path = "/users")
    public String users(Principal principal, Model model) {
        model.addAttribute("username", principal.getName());
        return "users";
    }
    @GetMapping("/secured")
    public String securedEndpoint(
    		OAuth2AuthenticationToken authentication,
    		HttpServletRequest request,
            HttpServletResponse response, Model model) {
    	 String idToken =null;
    	 
//    	 if (authentication instanceof OAuth2AuthenticationToken oauth2Auth) {
//             String clientRegistrationId = oauth2Auth.getAuthorizedClientRegistrationId();
//
//             OAuth2AuthorizedClient client =
//                     clientService.loadAuthorizedClient(clientRegistrationId, oauth2Auth.getName());
//
//             if (client != null) {
//                 String tokenValue = client.getAccessToken().getTokenValue();
//                 System.out.println( "Access Token: " + tokenValue);
//             }
//         }
    	 
    	if (authentication instanceof OAuth2AuthenticationToken) {
            OAuth2User oAuth2User = ((OAuth2AuthenticationToken) authentication).getPrincipal();

            if (oAuth2User instanceof OidcUser) {
                // Handle OIDC user (OpenID Connect)
                OidcUser oidcUser = (OidcUser) oAuth2User;
                idToken = oidcUser.getIdToken().getTokenValue();
                System.out.println("OIDC User: " + oidcUser.getEmail());
            } else {
                // Handle OAuth2 user
                System.out.println("OAuth2 User: " + oAuth2User.getAttributes());
                idToken=oAuth2User.getAttribute("token");
            }
        } 
            //else if (authentication instanceof JwtAuthenticationToken) {
//            System.out.println("JWT Token: " + (JwtAuthenticationToken)authentication.getName());
//        }

 
        
    	if (idToken==null && request.getSession().getAttribute("token")!=null) {
    		idToken=String.valueOf(request.getSession().getAttribute("token"));
    	}
         
        
         

        // ✅ Add token to response headers
    	if (idToken!=null) {
    		response.setHeader("Authorization", "Bearer " + idToken);
    	}
        System.out.println("Secured endpoint accessed! JWT token added to header. ID Token: " + idToken);
        model.addAttribute("username", authentication.getPrincipal().getName());
        return "secured";
    }
    @GetMapping(path = "/admin")
    public String admin(Principal principal, Model model) {
        model.addAttribute("username", principal.getName());
        return "admin";
    }
}