package dev.lydtech.security.simpleconfidentialclient;


import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Order(-101) // High priority, process before other filters
public class JwtToOAuth2TokenConverter extends OncePerRequestFilter {

    private final JwtDecoder jwtDecoder;

    public JwtToOAuth2TokenConverter(@Lazy JwtDecoder jwtDecoder) {
        this.jwtDecoder = jwtDecoder;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // ✅ Extract the token from the Authorization header
        String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authorizationHeader.substring(7);

        try {
            // ✅ Decode JWT using JwtDecoder
            Jwt jwt = jwtDecoder.decode(token);

            // ✅ Map roles manually from JWT claims
            Collection<GrantedAuthority> authorities = extractAuthorities(jwt);

            // ✅ Authenticate the JWT
            JwtAuthenticationToken jwtAuthentication = new JwtAuthenticationToken(jwt, authorities);

            // ✅ Convert JWT to OAuth2AuthenticationToken
            OAuth2AuthenticationToken oauth2Authentication = convertToOAuth2Authentication(jwtAuthentication);

            // ✅ Set authentication into SecurityContext
            SecurityContextHolder.getContext().setAuthentication(oauth2Authentication);

            System.out.println("✅ Successfully converted JWT to OAuth2AuthenticationToken");
        } catch (Exception e) {
            System.out.println("❌ Failed to decode JWT: " + e.getMessage());
        }

        filterChain.doFilter(request, response);
    }

    // ✅ Convert JWT claims to Spring authorities
    private Collection<GrantedAuthority> extractAuthorities(Jwt jwt) {
        List<String> roles = jwt.getClaimAsStringList("roles"); // Ensure "roles" is defined in JWT

        if (roles == null) {
            return Collections.emptyList();
        }

        return roles.stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
                .collect(Collectors.toList());
    }

    private OAuth2AuthenticationToken convertToOAuth2Authentication(JwtAuthenticationToken jwtAuthentication) {
        Map<String, Object> attributes = jwtAuthentication.getTokenAttributes();
        Collection<? extends GrantedAuthority> authorities = jwtAuthentication.getAuthorities();

        // ✅ Create OAuth2User using JWT attributes
        DefaultOAuth2User oAuth2User = new DefaultOAuth2User(
                authorities,
                attributes,
                "sub" // "sub" is the standard subject claim in JWT
        );

        // ✅ Create OAuth2AuthenticationToken using OAuth2User
        return new OAuth2AuthenticationToken(
                oAuth2User,
                authorities,
                "lydtech-confidential-client" // OAuth2 client ID (can be any string)
        );
    }
}
