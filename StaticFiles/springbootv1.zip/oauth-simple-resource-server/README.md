# Simple React OIDC / OAuth Resource Server

A very simple Spring Boot app that can be used as an OAuth Resource Server.

See https://www.lydtechconsulting.com/blog-oauth-oidc-part2.html for the accompanying article


## Running

```
# Build
./mvnw clean install
# Run
./mvnw spring-boot:run
```
