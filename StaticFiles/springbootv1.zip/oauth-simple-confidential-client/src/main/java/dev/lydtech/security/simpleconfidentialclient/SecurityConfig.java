package dev.lydtech.security.simpleconfidentialclient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;


import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.oidc.OidcUserInfo;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUserAuthority;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
import org.springframework.web.server.ServerWebExchange;

import java.net.URI;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.springframework.security.config.Customizer.withDefaults;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;


@Configuration
@EnableWebSecurity
class SecurityConfig {
	  private final JwtToOAuth2TokenConverter jwtToOAuth2TokenConverter;
	  public SecurityConfig(JwtToOAuth2TokenConverter jwtToOAuth2TokenConverter) {
	        this.jwtToOAuth2TokenConverter = jwtToOAuth2TokenConverter;
	    }
    @Bean
    protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        return new RegisterSessionAuthenticationStrategy(new SessionRegistryImpl());
    }

    @Bean
    OidcClientInitiatedLogoutSuccessHandler oidcLogoutSuccessHandler(ClientRegistrationRepository clientRegistrationRepository) {
        OidcClientInitiatedLogoutSuccessHandler successHandler = new OidcClientInitiatedLogoutSuccessHandler(clientRegistrationRepository);
        successHandler.setPostLogoutRedirectUri(URI.create("http://localhost:8082").toString());
        return successHandler;
    }


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, OidcClientInitiatedLogoutSuccessHandler oidcLogoutSuccessHandler,JwtToOAuth2AuthenticationTokenConverter jwtConverter) throws Exception {
//    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//
//    	if (authentication instanceof OAuth2AuthenticationToken oauth2Auth) {
//    	    System.out.println("OAuth2 token: " + oauth2Auth.getPrincipal());
//    	} else if (authentication instanceof JwtAuthenticationToken jwtAuth) {
//    	    System.out.println("JWT token: " + jwtAuth.getPrincipal());
//    	}
        http.authorizeHttpRequests(authorise ->
                authorise
                        .requestMatchers("/")
                        .permitAll()
                        .requestMatchers("/admin*")
                        .hasRole("admin")
                        .requestMatchers("/users*")
                        .hasAnyRole("user", "admin")
                        .anyRequest()
                        .authenticated());
        
        http
        .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt
                    .jwtAuthenticationConverter(jwtAuthenticationConverter()) // 👇 Map JWT roles
                )
            )        
        .oauth2Login(oauth2 -> oauth2
                    .userInfoEndpoint(userInfo -> userInfo.userService(oAuth2UserService())
                            //.oidcUserService(oidcUserService()                       		)
                        ))
                .logout(logout ->
                        logout.logoutSuccessHandler(oidcLogoutSuccessHandler));
        System.out.println("✅ Adding JwtToOAuth2TokenConverter BEFORE BearerTokenAuthenticationFilter");
        http.addFilterBefore(new JwtToOAuth2Filter(jwtConverter), 
                org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class);



        return http.build();
    }
    
   
    
    // ✅ Map "roles" claim from JWT token
 
    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        
        // ✅ Use custom converter to extract both roles and scopes
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(new CustomJwtGrantedAuthoritiesConverter());
        
        return jwtAuthenticationConverter;
    }

//    @Bean
//    public AuthenticationManagerResolver<ServerWebExchange> customAuthenticationManagerResolver() {
//        return exchange -> {
//            return authentication -> {
//                if (authentication instanceof JwtAuthenticationToken jwtAuth) {
//                    System.out.println("✅ JWT token detected, converting to OAuth2 token...");
//
//                    // 🔥 Extract roles from JWT
//                    Collection<GrantedAuthority> authorities = jwtAuth.getAuthorities();
//                    Map<String, Object> attributes = jwtAuth.getTokenAttributes();
//
//                    // 🔥 Create an OAuth2User from the JWT principal
//                    DefaultOAuth2User oAuth2User = new DefaultOAuth2User(
//                            authorities, // Roles
//                            attributes, // Claims
//                            "sub" // Key for the subject claim
//                    );
//
//                    // 🔥 Convert to OAuth2AuthenticationToken
//                    OAuth2AuthenticationToken oauth2Auth = new OAuth2AuthenticationToken(
//                            oAuth2User,
//                            authorities,
//                            "lydtech-confidential-client" // OAuth2 client ID
//                    );
//
//                    oauth2Auth.setAuthenticated(true);
//                    return oauth2Auth;
//                }
//
//                return authentication;
//            };
//        };
//    }
    
   
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, LoginSuccessHandler loginSuccessHandler) throws Exception {
        http
            .addFilterAfter(loginSuccessHandler, SecurityContextHolderAwareRequestFilter.class);

        return http.build();
    }
    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder.withJwkSetUri("http://localhost:8083/oauth2/jwks").build();
    }
    
    @Bean
    public OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService() {
        DefaultOAuth2UserService delegate = new DefaultOAuth2UserService();

        return userRequest -> {
            OAuth2User oAuth2User = delegate.loadUser(userRequest);

            // Log token for debugging
            String token = userRequest.getAccessToken().getTokenValue();
            System.out.println("Access Token: " + token);

            if (oAuth2User instanceof OidcUser) {
                // It's an OIDC user, just return it
                return (OidcUser) oAuth2User;
            }

            // If it's not OIDC, treat it as an OAuth2 user
            return oAuth2User;
        };
    }
    @Bean
    public OidcUserService oidcUserService() {
        OidcUserService delegate = new OidcUserService();
        return new OidcUserService() {
            @Override
            public OidcUser loadUser(OidcUserRequest userRequest) {
                OidcUser oidcUser = delegate.loadUser(userRequest);
                String token = userRequest.getAccessToken().getTokenValue();

                // ✅ Log token (for debugging)
                System.out.println("JWT Token: " + token);

                return oidcUser;
            }
        };
    }
    @Bean
    public GrantedAuthoritiesMapper userAuthoritiesMapper() {
        return (authorities) -> {
            Set<GrantedAuthority> mappedAuthorities = new HashSet<>();

            authorities.forEach(authority -> {
                if (authority instanceof OidcUserAuthority oidcUserAuthority) {

                    OidcUserInfo userInfo = oidcUserAuthority.getUserInfo();

                    // Map the claims found in idToken and/or userInfo
                    // to one or more GrantedAuthority's and add it to mappedAuthorities
                    Collection<String> roles = userInfo.getClaim("authorities");
                    if (roles != null)
                        roles.forEach(role -> mappedAuthorities.add(new SimpleGrantedAuthority(role)));
                }

            });

            return mappedAuthorities;
        };
    }
}