package dev.lydtech.security.simpleconfidentialclient;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class LoginSuccessHandler extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        Authentication authentication = (Authentication) request.getUserPrincipal();

        if (authentication instanceof OAuth2AuthenticationToken oauth2Token) {
            String token = oauth2Token.getPrincipal().getAttribute("access_token");
            if (token != null) {
            	System.out.println(" response.setHeader(\"Authorization\", \"Bearer \" + token)"+token);
                response.setHeader("Authorization", "Bearer " + token);
            }
        }

        filterChain.doFilter(request, response);
    }
}
