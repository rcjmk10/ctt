package dev.lydtech.security.simpleconfidentialclient;

 

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Map;

@Component
public class JwtToOAuth2AuthenticationTokenConverter {
	private String token;
	
    public String getToken() {
		return token;
	}

	public AbstractAuthenticationToken convert(JwtAuthenticationToken jwtAuthentication) {
        Jwt jwt = jwtAuthentication.getToken();
        Collection<? extends GrantedAuthority> authorities = jwtAuthentication.getAuthorities();

        // ✅ Extract claims and roles
        Map<String, Object> attributes = jwt.getClaims();
        
        DefaultOAuth2User oAuth2User = new DefaultOAuth2User(authorities, attributes, "sub");
       
        token= jwtAuthentication.getToken().getTokenValue();
       
        // ✅ Create OAuth2AuthenticationToken from JWT
        return new OAuth2AuthenticationToken(oAuth2User, authorities, "lydtech-confidential-client");
    }
}
