# Simple Spring Boot OAuth client app

A very simple Spring Boot app that can be used as an OAuth client / resource server as a 'confidential client'

See https://www.lydtechconsulting.com/blog-oauth-oidc-part3.html for the accompanying article


## Running

```
# Build
./mvnw clean install
# Run
./mvnw spring-boot:run
```
