# Simple Spring Boot Authorisation Server

A very simple Authorisation Server created using the spring-authorisation-server project

See https://www.lydtechconsulting.com/blog-oauth-oidc-part4.html for the accompanying article


## Running

```
# Build
./mvnw clean install
# Run
./mvnw spring-boot:run
```
