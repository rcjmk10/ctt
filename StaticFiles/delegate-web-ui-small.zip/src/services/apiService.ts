import axios from 'axios';

// Dummy data for UserInfo
const dummyUserInfo = {
  userName: 'John Doe',
  userId: '12345',
  horizonId: 'H123',
  email: 'john.doe@example.com',
  transitInfo: 'Bus 42'
};

// Dummy data for OutOfOfficeList
const dummyOutOfOfficeList = [
  { startDate: '2023-11-01', endDate: '2023-11-10', delegate: 'Jane Smith' },
  { startDate: '2023-12-01', endDate: '2023-12-05', delegate: 'John Doe' }
];

export const getUserInfo = async () => {
  // Simulate an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(dummyUserInfo), 1000);
  });
};

export const listOutOfOfficeData = async () => {
  // Simulate an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(dummyOutOfOfficeList), 1000);
  });
};

export const saveOutOfOfficeData = async (data: any) => {
  try {
    // Simulate a POST API call
    await axios.post('/api/v1/SaveOutofOfficeData', data);
    return { success: true, message: 'Data saved successfully' };
  } catch (error) {
    return { success: false, message: 'Failed to save data' };
  }
}; 