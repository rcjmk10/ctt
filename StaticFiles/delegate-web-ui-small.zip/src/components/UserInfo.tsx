import React, { useEffect, useState } from 'react';
import { getUserInfo } from '../services/apiService';

const UserInfo: React.FC = () => {
  const [userInfo, setUserInfo] = useState({
    userName: '',
    userId: '',
    horizonId: '',
    email: '',
    transitInfo: ''
  });

  useEffect(() => {
    const fetchUserInfo = async () => {
      const data = await getUserInfo() as {
        userName: string;
        userId: string;
        horizonId: string;
        email: string;
        transitInfo: string;
      };
      setUserInfo(data);
    };
    fetchUserInfo();
  }, []);

  return (
    <div className="user-info">
      <h3 className="user-info-header">{userInfo.userName}</h3>
      <table className="user-info-table">
        <tbody>
          <tr>
            <td>User ID:</td>
            <td>{userInfo.userId}</td>
          </tr>
          <tr>
            <td>Horizon ID:</td>
            <td>{userInfo.horizonId}</td>
          </tr>
          <tr>
            <td>Email:</td>
            <td>{userInfo.email}</td>
          </tr>
          <tr>
            <td>Transit Info:</td>
            <td>{userInfo.transitInfo}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default UserInfo; 