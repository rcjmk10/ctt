import React, { useState, useEffect } from 'react';
import { listOutOfOfficeData, saveOutOfOfficeData } from '../services/apiService';
import ReactModal from 'react-modal';

interface OutOfOfficeEntry {
  startDate: string;
  endDate: string;
  delegate: string;
}

const OutofOfficeManagement: React.FC = () => {
  const [entries, setEntries] = useState<OutOfOfficeEntry[]>([]);
  const [newEntry, setNewEntry] = useState<OutOfOfficeEntry>({ startDate: '', endDate: '', delegate: '' });
  const [options, setOptions] = useState<string[]>([]);
  const [message, setMessage] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const fetchOutOfOfficeData = async () => {
      const data = await listOutOfOfficeData() as OutOfOfficeEntry[];
      setEntries(data);
    };
    fetchOutOfOfficeData();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewEntry({ ...newEntry, [name]: value });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setOptions(prev => checked ? [...prev, value] : prev.filter(option => option !== value));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await saveOutOfOfficeData({ ...newEntry, options });
    setMessage(result.message);
    setIsModalOpen(true);
    if (result.success) {
      setEntries([...entries, newEntry]);
      setNewEntry({ startDate: '', endDate: '', delegate: '' });
      setOptions([]);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="out-of-office-management">
      <h3 className="out-of-office-header">Manage your out of office</h3>
      <ReactModal 
        isOpen={isModalOpen} 
        onRequestClose={closeModal} 
        contentLabel="Submission Result"
        style={{
          content: {
            top: '50%',
            left: '50%',
            right: 'auto',
            bottom: 'auto',
            marginRight: '-50%',
            transform: 'translate(-50%, -50%)',
            width: '300px',
            height: '200px',
            padding: '20px'
          }
        }}
      >
        <h2>Submission Result</h2>
        <p>{message}</p>
        <button onClick={closeModal}>Close</button>
      </ReactModal>
      <table className="out-of-office-table" style={{ width: '90%' }}>
        <thead>
          <tr>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Delegate</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((entry, index) => (
            <tr key={index} className="out-of-office-row">
              <td>{entry.startDate}</td>
              <td>{entry.endDate}</td>
              <td>{entry.delegate}</td>
              <td><button>Edit</button></td>
            </tr>
          ))}
        </tbody>
      </table>

      <hr style={{ border: '1px solid grey', margin: '20px 0' }} />

      <h2 className="out-of-office-create-header">Create new out of office</h2>
 
      <form onSubmit={handleSubmit} className="out-of-office-form">
        <table>
          <tbody>
            <tr>
              <td className="form-label">Start Date:</td>
              <td className="form-input"><input type="date" name="startDate" value={newEntry.startDate} onChange={handleInputChange} /></td>
            </tr>
            <tr>
              <td className="form-label">End Date:</td>
              <td className="form-input"><input type="date" name="endDate" value={newEntry.endDate} onChange={handleInputChange} /></td>
            </tr>
            <tr>
              <td className="form-label">Delegate:</td>
              <td className="form-input">
                <select name="delegate" value={newEntry.delegate} onChange={handleInputChange}>
                  <option value="">Select a delegate</option>
                  <option value="John Doe">John Doe</option>
                  <option value="Jane Smith">Jane Smith</option>
                </select>
              </td>
            </tr>
            <tr>
              <td className="form-label">Options:</td>
              <td className="form-input">
                <div className="checkbox-group">
                  <label><input type="checkbox" value="PPM" checked={options.includes('PPM')} onChange={handleCheckboxChange} /> PPM</label>
                  <label><input type="checkbox" value="ServiceNow" checked={options.includes('ServiceNow')} onChange={handleCheckboxChange} /> ServiceNow</label>
                  <label><input type="checkbox" value="Teller" checked={options.includes('Teller')} onChange={handleCheckboxChange} /> Teller</label>
                  <label><input type="checkbox" value="Email" checked={options.includes('Email')} onChange={handleCheckboxChange} /> Email</label>
                </div>
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="form-description">
                <p>
                  To create a new out of office entry, fill in the form with the start and end dates, select a delegate, and choose any additional options. Click 'Submit' to save your entry. After submission, a confirmation message will appear, and the new entry will be added to the top of the list. You can review and update entries as needed to ensure your out of office plans are accurately recorded.
                </p>
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="form-submit">
                <button type="submit">Submit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default OutofOfficeManagement; 