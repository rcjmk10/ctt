import React, { useState, useEffect } from 'react';
import { listOutOfOfficeData, saveOutOfOfficeData, getDelegatedApplications, lookupEmployees } from '../services/apiService';
import ReactModal from 'react-modal';
import { useTranslation } from 'react-i18next';

interface OutOfOfficeEntry {
  startDate: string;
  endDate: string;
  delegate: string;
}

const OutofOfficeManagement: React.FC = () => {
  const { t } = useTranslation();

  const today = new Date();
  const sevenDaysLater = new Date();
  sevenDaysLater.setDate(today.getDate() + 7);

  const [entries, setEntries] = useState<OutOfOfficeEntry[]>([]);
  const [delegatedApplications, setDelegatedApplications] = useState<string[]>([]);
  const [employeeOptions, setEmployeeOptions] = useState<{ fullName: string; email: string; transit: string; }[]>([]);

  const [newEntry, setNewEntry] = useState<OutOfOfficeEntry>({ startDate: today.toISOString().split('T')[0], endDate: sevenDaysLater.toISOString().split('T')[0], delegate: '' });
  const [options, setOptions] = useState<string[]>([]);
  const [message, setMessage] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const fetchOutOfOfficeData = async () => {
      const data = await listOutOfOfficeData() as OutOfOfficeEntry[];
      setEntries(data);
    };
    fetchOutOfOfficeData();

    const fetchDelegatedApplications = async () => {
      try {
        const apps = await getDelegatedApplications();
        setDelegatedApplications(apps);
      } catch (error) {
        console.error('Error fetching delegated applications:', error);
      }
    };
    fetchDelegatedApplications();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewEntry(prev => {
      const updatedEntry = { ...prev, [name]: value };
      if (name === 'startDate' && new Date(updatedEntry.endDate) <= new Date(value)) {
        const newEndDate = new Date(value);
        newEndDate.setDate(newEndDate.getDate() + 1);
        updatedEntry.endDate = newEndDate.toISOString().split('T')[0];
      }
      return updatedEntry;
    });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setOptions(prev => checked ? [...prev, value] : prev.filter(option => option !== value));
  };

  const handleKeywordChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const keyword = e.target.value;
    if (keyword.length > 2) { // Fetch employees if keyword is longer than 2 characters
      const employees = await lookupEmployees(keyword);
      setEmployeeOptions(employees);
    } else {
      setEmployeeOptions([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await saveOutOfOfficeData({ ...newEntry, options });
    setMessage(result.message);
    setIsModalOpen(true);
    if (result.success) {
      setEntries([...entries, newEntry]);
      setNewEntry({ startDate: today.toISOString().split('T')[0], endDate: sevenDaysLater.toISOString().split('T')[0], delegate: '' });
      setOptions([]);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="out-of-office-management">
      <h3 className="out-of-office-header">{t('manageOutOfOffice')}</h3>
      <ReactModal 
        isOpen={isModalOpen} 
        onRequestClose={closeModal} 
        contentLabel={t('submissionResult')}
        style={{
          content: {
            top: '50%',
            left: '50%',
            right: 'auto',
            bottom: 'auto',
            marginRight: '-50%',
            transform: 'translate(-50%, -50%)',
            width: '300px',
            height: '200px',
            padding: '20px'
          }
        }}
      >
        <h2>{t('submissionResult')}</h2>
        <p>{message}</p>
        <button onClick={closeModal}>{t('close')}</button>
      </ReactModal>
      <table className="out-of-office-table" style={{ width: '90%' }}>
        <thead>
          <tr>
            <th>{t('startDate')}</th>
            <th>{t('endDate')}</th>
            <th>{t('delegate')}</th>
            <th>{t('edit')}</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((entry, index) => (
            <tr key={index} className="out-of-office-row">
              <td>{entry.startDate}</td>
              <td>{entry.endDate}</td>
              <td>{entry.delegate}</td>
              <td><button>{t('edit')}</button></td>
            </tr>
          ))}
        </tbody>
      </table>

      <hr style={{ border: '1px solid grey', margin: '20px 0' }} />

      <h2 className="out-of-office-create-header">{t('createNewOutOfOffice')}</h2>

      <form onSubmit={handleSubmit} className="out-of-office-form">
        <table>
          <tbody>
            <tr>
              <td className="form-label">{t('startDate')}:</td>
              <td className="form-input"><input type="date" name="startDate" value={newEntry.startDate} onChange={handleInputChange} /></td>
            </tr>
            <tr>
              <td className="form-label">{t('endDate')}:</td>
              <td className="form-input"><input type="date" name="endDate" value={newEntry.endDate} onChange={handleInputChange} /></td>
            </tr>
            <tr>
              <td className="form-label">{t('delegate')}:</td>
              <td className="form-input">
                <input type="text" placeholder="Search delegate..." onChange={handleKeywordChange} />
                <br/>
                <select name="delegate" value={newEntry.delegate} onChange={handleInputChange}>
                  <option value="">Select a delegate</option>
                  {employeeOptions.map((employee) => (
                    <option key={employee.email} value={employee.fullName}>{employee.fullName} - {employee.email}</option>
                  ))}
                </select>
              </td>
            </tr>
            <tr>
              <td className="form-label">{t('options')}:</td>
              <td className="form-input">
                <div className="checkbox-group">
                  {delegatedApplications.map((app) => (
                    <label key={app}><input type="checkbox" value={app} checked={options.includes(app)} onChange={handleCheckboxChange} /> {app}</label>
                  ))}
                </div>
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="form-description">
                <p>{t('outOfOfficeFormDescription')}</p>
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="form-submit">
                <button type="submit">{t('submit')}</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default OutofOfficeManagement; 