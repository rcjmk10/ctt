import React, { useEffect, useState } from 'react';
import { getUserInfo } from '../services/apiService';
import { useTranslation } from 'react-i18next';

const UserInfo: React.FC = () => {
  const { t } = useTranslation();
  const [userInfo, setUserInfo] = useState({
    userName: '',
    userId: '',
    horizonId: '',
    email: '',
    transitInfo: ''
  });

  useEffect(() => {
    const fetchUserInfo = async () => {
      const data = await getUserInfo() as {
        userName: string;
        userId: string;
        horizonId: string;
        email: string;
        transitInfo: string;
      };
      setUserInfo(data);
    };
    fetchUserInfo();
  }, []);

  return (
    <div className="user-info">
      <h3 className="user-info-header">{t('userInfoHeader')}</h3>
      <table className="user-info-table">
        <tbody>
          <tr>
            <td>{t('userId')}:</td>
            <td>{userInfo.userId}</td>
          </tr>
          <tr>
            <td>{t('horizonId')}:</td>
            <td>{userInfo.horizonId}</td>
          </tr>
          <tr>
            <td>{t('email')}:</td>
            <td>{userInfo.email}</td>
          </tr>
          <tr>
            <td>{t('transitInfo')}:</td>
            <td>{userInfo.transitInfo}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default UserInfo; 