import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import './App.css'
import UserInfo from './components/UserInfo'
import OutofOfficeManagement from './components/OutofOfficeManagement'
import './services/styles.css'
import './services/i18n'
import { useTranslation } from 'react-i18next'
import { fetchSupportedLanguages } from './app/api/apiSlice'
import { RootState, AppDispatch } from './store'

function App() {
  const { t, i18n } = useTranslation()
  const dispatch = useDispatch<AppDispatch>()
  const languages = useSelector((state: RootState) => state.api.supportedLanguages || ['en', 'fr', 'es']);
  

  useEffect(() => {
    dispatch(fetchSupportedLanguages())
  }, [dispatch])

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng)
  }

  return (
    <div className="app-container">
      <div className="language-switcher top-right">
      {Array.isArray(languages) && languages.length > 0 ? (
        languages.map((lng) => (
          <button key={lng} onClick={() => changeLanguage(lng)}>
            {lng.toUpperCase()}
          </button>
        ))
      ) : (
        <span>No languages available.</span>
      )}
      </div>
      <h4 className="header">{t('delegateApplication')}</h4>
      <div className="flex-container">
        <div className="flex-item flex-item-left">
          <UserInfo />
        </div>
        <div className="flex-item flex-item-right">
          <OutofOfficeManagement />
        </div>
      </div>
    </div>
  )
}

export default App
