import axios from 'axios';

// Dummy data for UserInfo
const dummyUserInfo = {
  userName: 'John Doe',
  userId: '12345',
  horizonId: 'H123',
  email: 'john.doe@example.com',
  transitInfo: 'Bus 42'
};

// Dummy data for OutOfOfficeList
const dummyOutOfOfficeList = [
  { startDate: '2023-11-01', endDate: '2023-11-10', delegate: 'Jane Smith' },
  { startDate: '2023-12-01', endDate: '2023-12-05', delegate: 'John Doe' }
];

export const getUserInfo = async () => {
  // Simulate an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(dummyUserInfo), 1000);
  });
};

export const listOutOfOfficeData = async () => {
  // Simulate an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(dummyOutOfOfficeList), 1000);
  });
};

export const saveOutOfOfficeData = async (data: any) => {
  try {
    // Simulate a POST API call
    await axios.post('/api/v1/SaveOutofOfficeData', data);
    return { success: true, message: 'Data saved successfully' };
  } catch (error) {
    return { success: false, message: 'Failed to save data' };
  }
};

export const getSupportedLanguages = async () => {
  // const response = await fetch('/app/v1/GetSupportedLanguages');
  // if (!response.ok) {
  //   throw new Error('Failed to fetch supported languages');
  // }
  // return response.json();

  // Simulated dummy data for supported languages
  return ['en', 'fr', 'es'];
};

export const getDelegatedApplications = async () => {
  // const response = await fetch('/app/v1/GetDelegatedApplications');
  // if (!response.ok) {
  //   throw new Error('Failed to fetch delegated applications');
  // }
  // return response.json();

  // Simulated dummy data for delegated applications
  return ['PPM', 'ServiceNow', 'Teller', 'Email'];
};

export const lookupEmployees = async (keyword: string) => {
  // const response = await fetch(`/app/v1/LookupEmployees?keyword=${keyword}`);
  // if (!response.ok) {
  //   throw new Error('Failed to fetch employees');
  // }
  // return response.json();

  // Simulated dummy data for employees
  return [
    { fullName: 'Alice Johnson', email: 'alice.johnson@example.com', transit: 'Bus 21' },
    { fullName: 'Bob Smith', email: 'bob.smith@example.com', transit: 'Train 5' },
    { fullName: 'Charlie Brown', email: 'charlie.brown@example.com', transit: 'Bus 42' }
  ];
}; 