import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Define the initial state and its type
interface ApiState {
  userInfo: any;
  outOfOfficeList: [];
  supportedLanguages:  [];
  delegatedApplications: [];
  employeeOptions: { fullName: string; email: string; transit: string; }[];
  loading: boolean;
  error: string | null;
}

const initialState: ApiState = {
  userInfo: null,
  outOfOfficeList: [],
  supportedLanguages: [],
  delegatedApplications: [],
  employeeOptions: [],
  loading: false,
  error: null,
};

// Define async thunks for each API call
export const fetchUserInfo = createAsyncThunk('api/fetchUserInfo', async () => {
  const response = await axios.get('/api/v1/GetUserInfo');
  return response.data;
});

export const fetchOutOfOfficeData = createAsyncThunk('api/fetchOutOfOfficeData', async () => {
  const response = await axios.get('/api/v1/GetOutOfOfficeData');
  return response.data;
});

export const fetchSupportedLanguages = createAsyncThunk('api/fetchSupportedLanguages', async () => {
  const response = await axios.get('/api/v1/GetSupportedLanguages');
  console.log("API Response:", response.data);
  return ['en', 'fr', 'es'];
  //return response.data;
});

export const fetchDelegatedApplications = createAsyncThunk('api/fetchDelegatedApplications', async () => {
  const response = await axios.get('/api/v1/GetDelegatedApplications');
  return response.data;
});

export const fetchEmployeeOptions = createAsyncThunk('api/fetchEmployeeOptions', async (keyword: string) => {
  const response = await axios.get(`/api/v1/LookupEmployees?keyword=${keyword}`);
  return response.data;
});

// Create the slice
const apiSlice = createSlice({
  name: 'api',
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchUserInfo.fulfilled, (state, action) => {
        state.userInfo = action.payload;
      })
      .addCase(fetchOutOfOfficeData.fulfilled, (state, action) => {
        state.outOfOfficeList = action.payload;
      })
      .addCase(fetchSupportedLanguages.fulfilled, (state, action) => {
        state.supportedLanguages = action.payload;
      })
      .addCase(fetchDelegatedApplications.fulfilled, (state, action) => {
        state.delegatedApplications = action.payload;
      })
      .addCase(fetchEmployeeOptions.fulfilled, (state, action) => {
        state.employeeOptions = action.payload;
      })
      .addMatcher(
        action => action.type.endsWith('/pending'),
        state => {
          state.loading = true;
          state.error = null;
        }
      )
      .addMatcher(
        action => action.type.endsWith('/rejected'),
        (state, action) => {
          state.loading = false;
          state.error = action.error.message || 'An error occurred';
        }
      );
  }
});

export default apiSlice.reducer;